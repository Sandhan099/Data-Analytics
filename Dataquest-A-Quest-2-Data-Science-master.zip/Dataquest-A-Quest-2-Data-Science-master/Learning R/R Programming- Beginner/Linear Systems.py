## In this course, we'll focus on understanding linear functions

