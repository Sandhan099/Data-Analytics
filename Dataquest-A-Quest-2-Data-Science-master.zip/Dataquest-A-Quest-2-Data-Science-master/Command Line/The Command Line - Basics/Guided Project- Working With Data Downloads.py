## In this script, we'll be working with an education data set in ZIP format.
## We'll learn how to extract the files inside the ZIP download and then work with them


