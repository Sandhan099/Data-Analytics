## In this script, In this challenge, we will practice the basics of using the command line by working with files in the filesystem
