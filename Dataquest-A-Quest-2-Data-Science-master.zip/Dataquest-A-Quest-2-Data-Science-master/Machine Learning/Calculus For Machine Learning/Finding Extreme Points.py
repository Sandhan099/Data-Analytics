## Introduction To Derivatives


## Differentiation

import matplotlib.pyplot as plt
import numpy as np
x = np.linspace(-5,6,110)
y = -2*x + 3
plt.plot(x,y)


## Critical Points


## Extreme Values


## Power Rule


derivative_one = "5x^4"
derivative_two = "9x^8"
slope_one = 80
slope_two = 0


## Linearity Of Differentiation

d_one = "5x4 - 1"
d_two = "3x2 - 2x"
slope_three = 4
slope_four = 8


## END
